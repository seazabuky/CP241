public class ApplicationDriver {
    public static void main(String[] args) {
        Person sea = new Person();
        
        sea.setAge(20);
        System.out.println("Sea is " + sea.getAge()+" year old.");
        
        sea.setFavouriteColour("Pink");
        System.out.println("Sea's favourite colour is "+sea.getFavouriteColour()+".");
    }
}
