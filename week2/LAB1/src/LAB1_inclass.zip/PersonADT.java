public interface PersonADT {
    public int calculateAge(); 
        
}
